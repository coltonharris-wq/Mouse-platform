# Orgo Replica TypeScript SDK

[![npm version](https://img.shields.io/npm/v/orgo-replica.svg)](https://www.npmjs.com/package/orgo-replica)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0-blue.svg)](https://www.typescriptlang.org/)
[![Node.js](https://img.shields.io/badge/Node.js-18+-green.svg)](https://nodejs.org/)

A TypeScript/JavaScript SDK for controlling cloud VMs via the Orgo Replica API. Automate screenshots, mouse/keyboard input, command execution, and more.

## Features

- 🔌 **WebSocket-based real-time control** - Low-latency communication with VMs
- 📸 **Screenshot capture** - PNG, JPEG, WebP formats with region capture
- 🖱️ **Mouse control** - Click, move, scroll, drag operations
- ⌨️ **Keyboard input** - Type text, press keys, keyboard shortcuts
- 💻 **Command execution** - Run shell commands and get output
- 🖥️ **VM management** - Create, start, stop, resize VMs
- 🤖 **AI-ready** - Perfect for AI agents that need to control computers
- 📘 **Fully typed** - Complete TypeScript definitions

## Installation

```bash
npm install orgo-replica
```

## Quick Start

```typescript
import { Computer, VMManager, VMPresets } from 'orgo-replica';

// Configure with your API key
const API_KEY = 'your-api-key';

// Create a VM
const vms = new VMManager({ apiKey: API_KEY });
const vm = await vms.create('my-vm', VMPresets.standard);
await vms.start(vm.id);

// Connect to the VM
const computer = new Computer({ apiKey: API_KEY });
await computer.connect(vm.id);

// Take a screenshot
const screenshot = await computer.screenshot();
fs.writeFileSync('screen.png', screenshot);

// Control the VM
await computer.click(100, 200);
await computer.type('Hello World');
await computer.press('return');

// Run commands
const output = await computer.run('echo "Hello from VM"');
console.log(output);

// Cleanup
await computer.close();
await vms.delete(vm.id);
```

## API Reference

### Computer Class

The `Computer` class provides real-time control over a VM instance.

#### Constructor

```typescript
const computer = new Computer({
  apiKey: 'your-api-key',           // Required: API key
  baseUrl: 'https://api.orgo-replica.com/v1', // Optional: API base URL
  timeout: 30000,                   // Optional: Request timeout (ms)
  debug: false,                     // Optional: Enable debug logging
});
```

#### Connection Methods

| Method | Description |
|--------|-------------|
| `connect(vmId: string)` | Connect to a VM via WebSocket |
| `close()` | Close the connection |
| `isConnected()` | Check connection status |

#### Screenshot Methods

```typescript
// Basic screenshot
const screenshot = await computer.screenshot();

// With options
const screenshot = await computer.screenshot({
  format: 'png',        // 'png' | 'jpeg' | 'webp'
  quality: 90,          // 1-100 (for lossy formats)
  region: { x: 0, y: 0, width: 800, height: 600 },
  scale: 1,             // Scale factor
});
```

#### Mouse Control

```typescript
// Click at coordinates
await computer.click(100, 200);
await computer.click(100, 200, { button: 'right', count: 2 });

// Double-click and right-click helpers
await computer.doubleClick(100, 200);
await computer.rightClick(100, 200);

// Move mouse
await computer.move(500, 400);

// Drag
await computer.drag(100, 100, 500, 500);

// Scroll
await computer.scroll(0, -300);  // Scroll down

// Get position
const pos = await computer.getMousePosition();
console.log(pos.x, pos.y);
```

#### Keyboard Control

```typescript
// Type text
await computer.type('Hello World');
await computer.type('Hello', { delay: 50, pressEnter: true });

// Press keys
await computer.press('return');
await computer.press('control', 'a');  // Ctrl+A
await computer.press('control', 'shift', 't');  // Ctrl+Shift+T

// Hold and release
await computer.keyDown('shift');
await computer.type('uppercase');
await computer.keyUp('shift');
```

#### Command Execution

```typescript
// Run command (throws on non-zero exit)
const output = await computer.run('ls -la');

// Run with full details
const result = await computer.runDetailed('ls -la');
console.log(result.stdout);
console.log(result.stderr);
console.log(result.exitCode);
console.log(result.duration);
```

#### Utility Methods

```typescript
// Wait
await computer.wait(5000);  // 5 seconds

// Get screen resolution
const res = await computer.getScreenResolution();
console.log(`${res.width}x${res.height}`);
```

### VMManager Class

The `VMManager` class manages VM lifecycle operations.

```typescript
const vms = new VMManager({ apiKey: API_KEY });

// List VMs
const list = await vms.list();

// Get VM details
const vm = await vms.get('vm-id');

// Create VM
const newVM = await vms.create('name', {
  cpu: 2,
  memory: 4,      // GB
  storage: 50,    // GB
  os: 'ubuntu-22.04',
});

// Use presets
const vm = await vms.create('my-vm', VMPresets.standard);
// VMPresets: minimal, basic, standard, performance, highPerformance

// VM operations
await vms.start(vm.id);
await vms.stop(vm.id, force = false);
await vms.restart(vm.id);
await vms.delete(vm.id);

// Resize
await vms.resize(vm.id, { memory: 8 });

// Set resolution
await vms.setResolution(vm.id, { width: 1920, height: 1080 });
// ResolutionPresets: laptop, fullHD, qhd, uhd, xga, hd

// Wait for status
await vms.waitForStatus(vm.id, 'running', timeout = 60000);

// File transfer
await vms.uploadFile(vm.id, './local-file.txt', { 
  destination: '/home/user/file.txt',
  permissions: '644'
});

const file = await vms.downloadFile(vm.id, '/home/user/file.txt');
fs.writeFileSync(file.filename, file.data);
```

## Examples

### Basic Control

```typescript
import { Computer } from 'orgo-replica';

const comp = new Computer({ apiKey: 'xxx' });
await comp.connect('vm-123');

await comp.screenshot();
await comp.click(100, 200);
await comp.type('Hello World');

await comp.close();
```

See `examples/basic.ts` for a complete example.

### AI Agent Control

```typescript
// The SDK is designed for AI agents
while (!taskComplete) {
  // AI sees the screen
  const screenshot = await computer.screenshot();
  const base64Image = screenshot.toString('base64');
  
  // Send to vision model (GPT-4V, Claude, etc.)
  const action = await aiModel.decideAction(base64Image);
  
  // Execute AI's decision
  if (action.type === 'click') {
    await computer.click(action.x, action.y);
  } else if (action.type === 'type') {
    await computer.type(action.text);
  }
}
```

See `examples/ai-control.ts` for a complete AI integration example.

### Browser Automation

```typescript
await computer.run('google-chrome &');
await computer.wait(3000);

// Navigate
await computer.click(500, 70);  // Address bar
await computer.type('https://example.com', true);
await computer.wait(3000);

// Interact
await computer.click(800, 400);
await computer.type('Hello World');
```

See `examples/browser-automation.ts` for comprehensive browser automation examples.

## Development

### Build

```bash
npm install
npm run build
```

### Run Examples

```bash
# Set your API key
export ORGO_API_KEY=your-api-key
export ORGO_VM_ID=your-vm-id

# Run examples
npx ts-node examples/basic.ts
npx ts-node examples/ai-control.ts
npx ts-node examples/browser-automation.ts
```

### Package

```bash
npm pack
```

This creates `orgo-replica-1.0.0.tgz` ready for publishing.

### Publish

```bash
npm publish
```

## Environment Variables

| Variable | Description |
|----------|-------------|
| `ORGO_API_KEY` | Your Orgo Replica API key |
| `ORGO_VM_ID` | Default VM ID for examples |

## TypeScript Support

The SDK is written in TypeScript and includes complete type definitions:

```typescript
import { 
  Computer, 
  VMManager, 
  VM, 
  ScreenshotOptions, 
  ClickOptions,
  CommandResult 
} from 'orgo-replica';
```

## License

MIT

## Support

For issues and feature requests, please use the [GitHub issue tracker](https://github.com/orgo-replica/orgo-replica-ts/issues).
