/**
 * AI Control Example - Orgo Replica TypeScript SDK
 * 
 * Demonstrates using an AI model to control the VM.
 * The AI can see the screen and decide what actions to take.
 */

import { Computer, VMManager } from '../src/index.js';
import * as fs from 'fs';
import * as path from 'path';

// Configuration
const API_KEY = process.env.ORGO_API_KEY || 'your-api-key-here';
const VM_ID = process.env.ORGO_VM_ID || 'your-vm-id-here';

/**
 * AI Agent that can control the VM
 */
class AIController {
  private computer: Computer;
  private screenshotDir: string;

  constructor(computer: Computer) {
    this.computer = computer;
    this.screenshotDir = path.join(process.cwd(), 'ai-screenshots');
    
    // Create screenshot directory
    if (!fs.existsSync(this.screenshotDir)) {
      fs.mkdirSync(this.screenshotDir, { recursive: true });
    }
  }

  /**
   * Capture and save a screenshot
   */
  async capture(stepName: string): Promise<string> {
    const screenshot = await this.computer.screenshot();
    const filename = path.join(this.screenshotDir, `${Date.now()}_${stepName}.png`);
    fs.writeFileSync(filename, screenshot);
    console.log(`📸 Screenshot saved: ${filename}`);
    return filename;
  }

  /**
   * Click on an element (coordinates would come from AI vision model)
   */
  async clickElement(x: number, y: number, elementName: string): Promise<void> {
    console.log(`🖱️  AI clicking on ${elementName} at (${x}, ${y})`);
    await this.computer.click(x, y);
    await this.computer.wait(500);
  }

  /**
   * Type text as directed by AI
   */
  async typeText(text: string, fieldName: string): Promise<void> {
    console.log(`⌨️  AI typing in ${fieldName}: "${text}"`);
    await this.computer.type(text);
    await this.computer.wait(300);
  }

  /**
   * Navigate to a URL (assuming browser is open)
   */
  async navigateToUrl(url: string): Promise<void> {
    console.log(`🌐 AI navigating to: ${url}`);
    
    // Click on address bar (approximate position)
    await this.computer.click(500, 50);
    await this.computer.wait(200);
    
    // Select all and type new URL
    await this.computer.press('control', 'a');
    await this.computer.type(url);
    await this.computer.press('return');
    
    // Wait for page load
    await this.computer.wait(3000);
  }

  /**
   * Search for something (assuming search box is focused)
   */
  async search(query: string): Promise<void> {
    console.log(`🔍 AI searching for: "${query}"`);
    await this.computer.type(query, { pressEnter: true });
    await this.computer.wait(2000);
  }

  /**
   * Scroll to find content
   */
  async scrollToFind(direction: 'up' | 'down', iterations = 3): Promise<void> {
    console.log(`📜 AI scrolling ${direction} ${iterations} times`);
    const deltaY = direction === 'up' ? -300 : 300;
    
    for (let i = 0; i < iterations; i++) {
      await this.computer.scroll(0, deltaY);
      await this.computer.wait(500);
    }
  }

  /**
   * Take a screenshot and analyze (placeholder for AI vision model)
   * In a real implementation, this would send the image to GPT-4V, Claude, etc.
   */
  async analyzeScreen(stepName: string): Promise<{
    description: string;
    suggestedAction: string;
    clickTarget?: { x: number; y: number };
  }> {
    const screenshotPath = await this.capture(stepName);
    
    // Placeholder: In real implementation, send to vision model
    console.log(`🧠 Analyzing screen: ${screenshotPath}`);
    
    return {
      description: 'Screen captured for analysis',
      suggestedAction: 'Continue with next step',
    };
  }
}

/**
 * Example task automation using AI control
 */
async function automateTask(task: string): Promise<void> {
  console.log('🤖 AI Control Example');
  console.log('=====================\n');
  console.log(`Task: ${task}\n`);

  const computer = new Computer({
    apiKey: API_KEY,
    debug: true,
  });

  try {
    await computer.connect(VM_ID);
    console.log('✅ Connected to VM\n');

    const ai = new AIController(computer);

    // Example: Automate opening a browser and searching
    console.log('📋 Starting automation workflow...\n');

    // Step 1: Initial screenshot
    console.log('Step 1: Capture initial state');
    await ai.analyzeScreen('initial');

    // Step 2: Open browser (assuming there's a browser icon)
    console.log('\nStep 2: Open browser');
    // This would use AI vision to find the browser icon
    // await ai.clickElement(100, 100, 'Chrome icon');
    await computer.run('google-chrome &');
    await computer.wait(3000);
    await ai.capture('browser_opened');

    // Step 3: Navigate to a website
    console.log('\nStep 3: Navigate to website');
    await ai.navigateToUrl('https://www.google.com');
    await ai.capture('google_loaded');

    // Step 4: Perform search
    console.log('\nStep 4: Search for information');
    await ai.clickElement(500, 300, 'Search box');
    await ai.search('OpenAI ChatGPT');
    await ai.capture('search_results');

    // Step 5: Scroll and explore
    console.log('\nStep 5: Explore results');
    await ai.scrollToFind('down', 2);
    await ai.capture('scrolled');

    console.log('\n✅ Task automation completed!');
    console.log(`📁 Screenshots saved to: ${ai['screenshotDir']}`);

  } catch (error) {
    console.error('❌ Error:', error);
  } finally {
    await computer.close();
    console.log('\n🔌 Connection closed');
  }
}

/**
 * Integration example with actual AI vision API
 * (This is a template - implement with your preferred AI model)
 */
async function aiVisionExample(): Promise<void> {
  console.log('\n🧠 AI Vision Integration Example');
  console.log('================================\n');

  const computer = new Computer({
    apiKey: API_KEY,
    debug: false,
  });

  await computer.connect(VM_ID);

  // Template for integrating with AI vision models:
  // 1. Capture screenshot
  // 2. Send to GPT-4V, Claude, or other vision model
  // 3. Parse the response for actions
  // 4. Execute actions on the VM
  // 5. Repeat

  /*
  Example with pseudo-code:
  
  while (!taskComplete) {
    // Capture screen
    const screenshot = await computer.screenshot();
    
    // Send to AI vision model
    const response = await openai.chat.completions.create({
      model: 'gpt-4-vision-preview',
      messages: [
        {
          role: 'user',
          content: [
            { type: 'text', text: 'What do you see? What should I do next?' },
            { type: 'image_url', image_url: { url: `data:image/png;base64,${screenshot.toString('base64')}` } }
          ]
        }
      ]
    });
    
    // Parse and execute action
    const action = parseAIResponse(response);
    await executeAction(computer, action);
  }
  */

  console.log('💡 To use AI vision:');
  console.log('   1. Capture screenshot with await computer.screenshot()');
  console.log('   2. Send base64-encoded image to your AI model');
  console.log('   3. Parse response for coordinates and actions');
  console.log('   4. Execute with computer.click(), computer.type(), etc.');

  await computer.close();
}

// Run the examples
const task = process.argv[2] || 'Open browser and search for OpenAI';
automateTask(task)
  .then(() => aiVisionExample())
  .catch(console.error);
