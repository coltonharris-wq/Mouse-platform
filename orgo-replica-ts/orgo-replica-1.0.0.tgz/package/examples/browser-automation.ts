/**
 * Browser Automation Example - Orgo Replica TypeScript SDK
 * 
 * Demonstrates browser automation workflows including:
 * - Opening browsers
 * - Navigation
 * - Form filling
 * - Taking screenshots of web pages
 * - Multi-page workflows
 */

import { Computer, VMManager, ResolutionPresets } from '../src/index.js';
import * as fs from 'fs';
import * as path from 'path';

// Configuration
const API_KEY = process.env.ORGO_API_KEY || 'your-api-key-here';
const VM_ID = process.env.ORGO_VM_ID || 'your-vm-id-here';

/**
 * Browser automation helper class
 */
class BrowserAutomation {
  private computer: Computer;
  private defaultWait = 1000;

  constructor(computer: Computer) {
    this.computer = computer;
  }

  /**
   * Wait for page to load
   */
  async waitForLoad(ms = 3000): Promise<void> {
    await this.computer.wait(ms);
  }

  /**
   * Click on screen coordinates
   */
  async click(x: number, y: number): Promise<void> {
    await this.computer.click(x, y);
    await this.computer.wait(this.defaultWait);
  }

  /**
   * Type text with optional Enter key
   */
  async type(text: string, pressEnter = false): Promise<void> {
    await this.computer.type(text, { pressEnter });
    await this.computer.wait(this.defaultWait);
  }

  /**
   * Press keyboard shortcut
   */
  async shortcut(...keys: Parameters<Computer['press']>): Promise<void> {
    await this.computer.press(...keys);
    await this.computer.wait(this.defaultWait);
  }

  /**
   * Navigate to URL (Chrome/Chromeium assumed)
   */
  async navigateTo(url: string): Promise<void> {
    console.log(`  🌐 Navigating to: ${url}`);
    
    // Click address bar (typical Chrome position)
    await this.click(500, 70);
    
    // Select all and type new URL
    await this.shortcut('control', 'a');
    await this.type(url, true);
    
    await this.waitForLoad(3000);
  }

  /**
   * Fill a form field
   */
  async fillField(x: number, y: number, value: string): Promise<void> {
    await this.click(x, y);
    await this.shortcut('control', 'a');
    await this.type(value);
  }

  /**
   * Scroll down the page
   */
  async scrollDown(amount = 500): Promise<void> {
    await this.computer.scroll(0, amount);
    await this.computer.wait(500);
  }

  /**
   * Scroll up the page
   */
  async scrollUp(amount = 500): Promise<void> {
    await this.computer.scroll(0, -amount);
    await this.computer.wait(500);
  }

  /**
   * Take a screenshot and save it
   */
  async screenshot(name: string): Promise<void> {
    const screenshot = await this.computer.screenshot();
    const filename = path.join(process.cwd(), 'browser-screenshots', `${Date.now()}_${name}.png`);
    
    // Ensure directory exists
    const dir = path.dirname(filename);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    
    fs.writeFileSync(filename, screenshot);
    console.log(`  📸 Screenshot: ${filename}`);
  }

  /**
   * Click the browser back button
   */
  async goBack(): Promise<void> {
    await this.shortcut('alt', 'left');
  }

  /**
   * Click the browser forward button
   */
  async goForward(): Promise<void> {
    await this.shortcut('alt', 'right');
  }

  /**
   * Refresh the page
   */
  async refresh(): Promise<void> {
    await this.shortcut('f5');
    await this.waitForLoad(2000);
  }

  /**
   * Open a new tab
   */
  async newTab(): Promise<void> {
    await this.shortcut('control', 't');
    await this.waitForLoad(1000);
  }

  /**
   * Close current tab
   */
  async closeTab(): Promise<void> {
    await this.shortcut('control', 'w');
    await this.waitForLoad(500);
  }

  /**
   * Switch to next tab
   */
  async nextTab(): Promise<void> {
    await this.shortcut('control', 'tab');
    await this.waitForLoad(500);
  }

  /**
   * Switch to previous tab
   */
  async previousTab(): Promise<void> {
    await this.shortcut('control', 'shift', 'tab');
    await this.waitForLoad(500);
  }
}

/**
 * Example 1: Basic website navigation
 */
async function exampleBasicNavigation(browser: BrowserAutomation): Promise<void> {
  console.log('\n📘 Example 1: Basic Website Navigation');
  console.log('--------------------------------------');

  // Navigate to Google
  await browser.navigateTo('https://www.google.com');
  await browser.screenshot('google_homepage');

  // Search for something
  console.log('  🔍 Searching...');
  await browser.click(800, 400); // Search box (approximate)
  await browser.type('TypeScript SDK development', true);
  await browser.waitForLoad(3000);
  await browser.screenshot('search_results');

  // Scroll through results
  console.log('  📜 Scrolling results...');
  await browser.scrollDown(800);
  await browser.screenshot('scrolled_results');

  console.log('  ✅ Navigation example complete');
}

/**
 * Example 2: Multi-tab browsing
 */
async function exampleMultiTab(browser: BrowserAutomation): Promise<void> {
  console.log('\n📗 Example 2: Multi-Tab Browsing');
  console.log('----------------------------------');

  // Open first tab with news
  await browser.navigateTo('https://news.ycombinator.com');
  await browser.screenshot('hackernews');

  // Open new tab
  console.log('  📑 Opening new tab...');
  await browser.newTab();
  await browser.navigateTo('https://github.com');
  await browser.screenshot('github');

  // Open another tab
  console.log('  📑 Opening another tab...');
  await browser.newTab();
  await browser.navigateTo('https://stackoverflow.com');
  await browser.screenshot('stackoverflow');

  // Switch between tabs
  console.log('  🔄 Switching tabs...');
  await browser.previousTab();
  await browser.screenshot('back_to_github');
  
  await browser.previousTab();
  await browser.screenshot('back_to_hackernews');

  console.log('  ✅ Multi-tab example complete');
}

/**
 * Example 3: Form interaction
 */
async function exampleFormInteraction(browser: BrowserAutomation): Promise<void> {
  console.log('\n📙 Example 3: Form Interaction');
  console.log('--------------------------------');

  // Navigate to a form page (using a demo form site)
  await browser.navigateTo('https://httpbin.org/forms/post');
  await browser.screenshot('form_page');

  // Fill in form fields
  console.log('  📝 Filling form...');
  
  // These coordinates are approximate - adjust for actual page
  // Customer name
  await browser.fillField(400, 300, 'John Doe');
  
  // Scroll to see more fields
  await browser.scrollDown(200);
  await browser.screenshot('form_partially_filled');

  console.log('  ✅ Form interaction example complete');
  console.log('  💡 Note: Coordinates should be adjusted based on actual page layout');
}

/**
 * Example 4: Screenshot automation
 */
async function exampleScreenshotAutomation(browser: BrowserAutomation, urls: string[]): Promise<void> {
  console.log('\n📕 Example 4: Screenshot Automation');
  console.log('--------------------------------------');

  for (const url of urls) {
    console.log(`  📸 Capturing: ${url}`);
    
    try {
      await browser.navigateTo(url);
      
      // Wait for page to fully render
      await browser.waitForLoad(5000);
      
      // Generate filename from URL
      const filename = url.replace(/https?:\/\//, '').replace(/[^a-z0-9]/gi, '_').substring(0, 50);
      await browser.screenshot(filename);
      
      console.log(`    ✅ Captured: ${filename}`);
    } catch (error) {
      console.error(`    ❌ Failed to capture ${url}:`, error);
    }
  }

  console.log('  ✅ Screenshot automation complete');
}

/**
 * Example 5: Responsive testing
 */
async function exampleResponsiveTesting(computer: Computer, browser: BrowserAutomation): Promise<void> {
  console.log('\n📓 Example 5: Responsive Testing');
  console.log('----------------------------------');

  const resolutions = [
    { name: 'mobile', width: 375, height: 667 },
    { name: 'tablet', width: 768, height: 1024 },
    { name: 'desktop', width: 1920, height: 1080 },
  ];

  const testUrl = 'https://www.example.com';

  for (const res of resolutions) {
    console.log(`  📱 Testing ${res.name} (${res.width}x${res.height})`);
    
    // Note: In a real scenario, you might resize the browser window
    // This is simulated here with just screenshots at different scroll positions
    
    await browser.navigateTo(testUrl);
    await browser.waitForLoad(3000);
    
    // Take full page screenshot simulation (multiple scrolls)
    await browser.screenshot(`responsive_${res.name}_top`);
    
    await browser.scrollDown(800);
    await browser.screenshot(`responsive_${res.name}_middle`);
    
    await browser.scrollDown(800);
    await browser.screenshot(`responsive_${res.name}_bottom`);
  }

  console.log('  ✅ Responsive testing complete');
}

/**
 * Main function
 */
async function main(): Promise<void> {
  console.log('🌐 Browser Automation Example');
  console.log('============================\n');

  const computer = new Computer({
    apiKey: API_KEY,
    debug: false,
  });

  try {
    await computer.connect(VM_ID);
    console.log('✅ Connected to VM\n');

    // Get screen info
    const resolution = await computer.getScreenResolution();
    console.log(`📐 Screen: ${resolution.width}x${resolution.height}\n`);

    // Start Chrome
    console.log('🚀 Starting Chrome...');
    await computer.run('google-chrome --start-maximized &');
    await computer.wait(5000); // Wait for Chrome to start

    // Create browser automation helper
    const browser = new BrowserAutomation(computer);
    await browser.screenshot('chrome_started');

    // Run examples
    await exampleBasicNavigation(browser);
    await exampleMultiTab(browser);
    await exampleFormInteraction(browser);
    
    await exampleScreenshotAutomation(browser, [
      'https://www.google.com',
      'https://www.github.com',
      'https://stackoverflow.com',
    ]);
    
    await exampleResponsiveTesting(computer, browser);

    console.log('\n✅ All browser automation examples completed!');
    console.log(`📁 Screenshots saved to: ${path.join(process.cwd(), 'browser-screenshots')}`);

  } catch (error) {
    console.error('❌ Error:', error);
  } finally {
    await computer.close();
    console.log('\n🔌 Connection closed');
  }
}

// Run the examples
main().catch(console.error);
