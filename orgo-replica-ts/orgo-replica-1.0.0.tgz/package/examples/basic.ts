/**
 * Basic Example - Orgo Replica TypeScript SDK
 * 
 * Demonstrates basic VM control operations:
 * - Connecting to a VM
 * - Taking screenshots
 * - Clicking and typing
 * - Running commands
 */

import { Computer, VMManager, VMPresets } from '../src/index.js';

// Configuration - Replace with your actual API key
const API_KEY = process.env.ORGO_API_KEY || 'your-api-key-here';
const VM_ID = process.env.ORGO_VM_ID || 'your-vm-id-here';

async function main(): Promise<void> {
  console.log('🚀 Orgo Replica - Basic Example');
  console.log('================================\n');

  // Create VM manager instance
  const vms = new VMManager({
    apiKey: API_KEY,
    debug: true,
  });

  // List available VMs
  console.log('📋 Listing VMs...');
  try {
    const vmList = await vms.list();
    console.log(`Found ${vmList.length} VM(s):`);
    for (const vm of vmList) {
      console.log(`  - ${vm.name} (${vm.id}): ${vm.status}`);
    }
  } catch (error) {
    console.error('Failed to list VMs:', error);
  }

  console.log('\n---\n');

  // Create Computer instance for VM control
  const computer = new Computer({
    apiKey: API_KEY,
    debug: true,
  });

  try {
    // Connect to VM
    console.log('🔗 Connecting to VM...');
    await computer.connect(VM_ID);
    console.log('✅ Connected successfully!\n');

    // Get screen resolution
    console.log('📐 Getting screen resolution...');
    const resolution = await computer.getScreenResolution();
    console.log(`Screen: ${resolution.width}x${resolution.height}\n`);

    // Take a screenshot
    console.log('📸 Taking screenshot...');
    const screenshot = await computer.screenshot();
    console.log(`Screenshot captured: ${screenshot.length} bytes\n`);
    
    // Save screenshot to file (in a real scenario)
    // const fs = require('fs');
    // fs.writeFileSync('screenshot.png', screenshot);
    // console.log('💾 Screenshot saved to screenshot.png\n');

    // Move mouse to center of screen
    const centerX = Math.floor(resolution.width / 2);
    const centerY = Math.floor(resolution.height / 2);
    console.log(`🖱️  Moving mouse to center (${centerX}, ${centerY})...`);
    await computer.move(centerX, centerY);
    console.log('✅ Mouse moved\n');

    // Get current mouse position
    const mousePos = await computer.getMousePosition();
    console.log(`🖱️  Mouse position: (${mousePos.x}, ${mousePos.y})\n`);

    // Click at a position
    console.log('🖱️  Clicking at (100, 100)...');
    await computer.click(100, 100);
    console.log('✅ Clicked\n');

    // Right click
    console.log('🖱️  Right-clicking at (200, 200)...');
    await computer.rightClick(200, 200);
    console.log('✅ Right-clicked\n');

    // Type some text
    console.log('⌨️  Typing text...');
    await computer.type('Hello from Orgo Replica!');
    console.log('✅ Text typed\n');

    // Press Enter key
    console.log('⌨️  Pressing Enter...');
    await computer.press('return');
    console.log('✅ Enter pressed\n');

    // Type with Enter
    console.log('⌨️  Typing with Enter...');
    await computer.type('This is a new line', { pressEnter: true });
    console.log('✅ Typed with Enter\n');

    // Run a command
    console.log('💻 Running command: echo "Hello from VM"');
    const output = await computer.run('echo "Hello from VM"');
    console.log(`Output: ${output}\n`);

    // Run a more complex command
    console.log('💻 Running: uname -a');
    const uname = await computer.run('uname -a');
    console.log(`System info: ${uname}\n`);

    // Press keyboard shortcut (Ctrl+A to select all)
    console.log('⌨️  Pressing Ctrl+A...');
    await computer.press('control', 'a');
    console.log('✅ Shortcut pressed\n');

    // Scroll
    console.log('📜 Scrolling down...');
    await computer.scroll(0, 100);
    console.log('✅ Scrolled\n');

    console.log('✅ All basic operations completed successfully!');

  } catch (error) {
    console.error('❌ Error:', error);
  } finally {
    // Always close the connection
    console.log('\n🔌 Closing connection...');
    await computer.close();
    console.log('✅ Connection closed');
  }
}

// Run the example
main().catch(console.error);
