/**
 * Orgo Replica TypeScript SDK - Computer Class
 * 
 * Main class for controlling cloud VM instances.
 * Provides methods for screenshot capture, mouse/keyboard control,
 * command execution, and more.
 */

import { EventEmitter } from 'events';
import WebSocket from 'ws';
import {
  ComputerConfig,
  ScreenshotOptions,
  ClickOptions,
  TypeOptions,
  MoveOptions,
  CommandResult,
  MousePosition,
  Key,
  VM,
  APIError,
  WSMessage,
  ScreenResolution,
} from './types.js';

/**
 * Computer class for VM automation and control
 * 
 * @example
 * ```typescript
 * import { Computer } from 'orgo-replica';
 * 
 * const comp = new Computer({ apiKey: 'your-api-key' });
 * await comp.connect('vm-id');
 * 
 * const screenshot = await comp.screenshot();
 * await comp.click(100, 200);
 * await comp.type('Hello World');
 * 
 * await comp.close();
 * ```
 */
export class Computer extends EventEmitter {
  private apiKey: string;
  private baseUrl: string;
  private timeout: number;
  private debug: boolean;
  private ws: WebSocket | null = null;
  private vmId: string | null = null;
  private connected = false;
  private messageQueue: Map<string, { resolve: (value: unknown) => void; reject: (error: Error) => void }> = new Map();
  private messageId = 0;

  /**
   * Create a new Computer instance
   * 
   * @param config - Configuration options
   */
  constructor(config: ComputerConfig) {
    super();
    
    if (!config.apiKey) {
      throw new Error('API key is required');
    }
    
    this.apiKey = config.apiKey;
    this.baseUrl = config.baseUrl || 'https://api.orgo-replica.com/v1';
    this.timeout = config.timeout || 30000;
    this.debug = config.debug || false;
  }

  /**
   * Log debug messages if debug mode is enabled
   */
  private log(...args: unknown[]): void {
    if (this.debug) {
      console.log('[OrgoReplica]', ...args);
    }
  }

  /**
   * Make an HTTP request to the API
   */
  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const url = `${this.baseUrl}${endpoint}`;
    
    const headers: Record<string, string> = {
      'Authorization': `Bearer ${this.apiKey}`,
      'Content-Type': 'application/json',
      ...((options.headers as Record<string, string>) || {}),
    };

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.timeout);

    try {
      this.log('Request:', options.method || 'GET', url);
      
      const response = await fetch(url, {
        ...options,
        headers,
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const error = await response.json().catch(() => ({ message: 'Unknown error' })) as APIError;
        throw new Error(`API Error: ${error.message} (${response.status})`);
      }

      return await response.json() as T;
    } catch (error) {
      clearTimeout(timeoutId);
      throw error;
    }
  }

  /**
   * Connect to a VM via WebSocket
   * 
   * @param vmId - The VM identifier to connect to
   * @returns Promise that resolves when connected
   */
  async connect(vmId: string): Promise<void> {
    if (this.connected) {
      throw new Error('Already connected to a VM');
    }

    this.vmId = vmId;
    
    // Get VM details and WebSocket URL
    const vm = await this.request<{ vm: VM; wsUrl: string }>(`/vms/${vmId}/connect`);
    
    return new Promise((resolve, reject) => {
      const wsUrl = new URL(vm.wsUrl);
      wsUrl.searchParams.set('token', this.apiKey);

      this.ws = new WebSocket(wsUrl.toString());

      this.ws.on('open', () => {
        this.log('WebSocket connected to VM:', vmId);
        this.connected = true;
        this.emit('connected', vmId);
        resolve();
      });

      this.ws.on('message', (data: WebSocket.Data) => {
        this.handleMessage(data.toString());
      });

      this.ws.on('error', (error: Error) => {
        this.log('WebSocket error:', error);
        this.emit('error', error);
        reject(error);
      });

      this.ws.on('close', () => {
        this.log('WebSocket closed');
        this.connected = false;
        this.emit('disconnected');
      });

      // Connection timeout
      setTimeout(() => {
        if (!this.connected) {
          reject(new Error('Connection timeout'));
        }
      }, this.timeout);
    });
  }

  /**
   * Handle incoming WebSocket messages
   */
  private handleMessage(data: string): void {
    try {
      const message = JSON.parse(data) as WSMessage;
      
      if (message.type === 'response' && this.messageQueue.has(message.id)) {
        const { resolve } = this.messageQueue.get(message.id)!;
        this.messageQueue.delete(message.id);
        resolve(message.payload);
      } else if (message.type === 'error' && this.messageQueue.has(message.id)) {
        const { reject } = this.messageQueue.get(message.id)!;
        this.messageQueue.delete(message.id);
        reject(new Error((message.payload as { message: string }).message));
      } else if (message.type === 'event') {
        this.emit('event', message.payload);
      }
    } catch (error) {
      this.log('Failed to parse message:', error);
    }
  }

  /**
   * Send a command via WebSocket and wait for response
   */
  private sendCommand<T>(command: string, params: Record<string, unknown> = {}): Promise<T> {
    return new Promise((resolve, reject) => {
      if (!this.ws || !this.connected) {
        reject(new Error('Not connected to a VM'));
        return;
      }

      const id = `msg_${++this.messageId}`;
      const message: WSMessage = {
        type: 'command',
        id,
        payload: { command, params },
      };

      this.messageQueue.set(id, { resolve: resolve as (value: unknown) => void, reject });

      // Timeout handling
      setTimeout(() => {
        if (this.messageQueue.has(id)) {
          this.messageQueue.delete(id);
          reject(new Error(`Command timeout: ${command}`));
        }
      }, this.timeout);

      this.ws.send(JSON.stringify(message));
    });
  }

  /**
   * Capture a screenshot of the VM screen
   * 
   * @param options - Screenshot options
   * @returns Promise resolving to a Buffer containing the image
   */
  async screenshot(options: ScreenshotOptions = {}): Promise<Buffer> {
    this.log('Taking screenshot:', options);
    
    const result = await this.sendCommand<{ data: string; format: string }>('screenshot', {
      format: options.format || 'png',
      quality: options.quality || 90,
      region: options.region,
      scale: options.scale || 1,
    });

    // Convert base64 to Buffer
    return Buffer.from(result.data, 'base64');
  }

  /**
   * Click at a specific coordinate on the screen
   * 
   * @param x - X coordinate
   * @param y - Y coordinate
   * @param options - Click options
   */
  async click(x: number, y: number, options: ClickOptions = {}): Promise<void> {
    this.log('Clicking at:', x, y, options);
    
    await this.sendCommand('click', {
      x,
      y,
      button: options.button || 'left',
      count: options.count || 1,
      delay: options.delay || 50,
    });
  }

  /**
   * Double-click at a specific coordinate
   * 
   * @param x - X coordinate
   * @param y - Y coordinate
   * @param options - Click options (count is ignored)
   */
  async doubleClick(x: number, y: number, options: Omit<ClickOptions, 'count'> = {}): Promise<void> {
    await this.click(x, y, { ...options, count: 2 });
  }

  /**
   * Right-click at a specific coordinate
   * 
   * @param x - X coordinate
   * @param y - Y coordinate
   */
  async rightClick(x: number, y: number): Promise<void> {
    await this.click(x, y, { button: 'right' });
  }

  /**
   * Move the mouse to a specific coordinate
   * 
   * @param x - X coordinate
   * @param y - Y coordinate
   * @param options - Movement options
   */
  async move(x: number, y: number, options: MoveOptions = {}): Promise<void> {
    this.log('Moving mouse to:', x, y);
    
    await this.sendCommand('move', {
      x,
      y,
      duration: options.duration || 0,
    });
  }

  /**
   * Get current mouse position
   * 
   * @returns Current mouse position
   */
  async getMousePosition(): Promise<MousePosition> {
    return await this.sendCommand<MousePosition>('getMousePosition', {});
  }

  /**
   * Type text on the keyboard
   * 
   * @param text - Text to type
   * @param options - Typing options
   */
  async type(text: string, options: TypeOptions = {}): Promise<void> {
    this.log('Typing text:', text.substring(0, 50), text.length > 50 ? '...' : '');
    
    await this.sendCommand('type', {
      text,
      delay: options.delay || 10,
      pressEnter: options.pressEnter || false,
    });
  }

  /**
   * Press a key or key combination
   * 
   * @param keys - Key or keys to press
   */
  async press(...keys: Key[]): Promise<void> {
    this.log('Pressing keys:', keys.join('+'));
    
    await this.sendCommand('press', { keys });
  }

  /**
   * Press and hold a key
   * 
   * @param key - Key to hold
   */
  async keyDown(key: Key): Promise<void> {
    await this.sendCommand('keyDown', { key });
  }

  /**
   * Release a held key
   * 
   * @param key - Key to release
   */
  async keyUp(key: Key): Promise<void> {
    await this.sendCommand('keyUp', { key });
  }

  /**
   * Execute a shell command on the VM
   * 
   * @param command - Command to execute
   * @returns Promise resolving to command result
   */
  async run(command: string): Promise<string> {
    this.log('Running command:', command);
    
    const result = await this.sendCommand<CommandResult>('run', { command });
    
    if (result.exitCode !== 0) {
      throw new Error(`Command failed with exit code ${result.exitCode}: ${result.stderr}`);
    }
    
    return result.stdout;
  }

  /**
   * Execute a shell command and get full result details
   * 
   * @param command - Command to execute
   * @returns Promise resolving to full command result
   */
  async runDetailed(command: string): Promise<CommandResult> {
    this.log('Running command (detailed):', command);
    
    return await this.sendCommand<CommandResult>('run', { command });
  }

  /**
   * Get the screen resolution
   * 
   * @returns Screen resolution
   */
  async getScreenResolution(): Promise<ScreenResolution> {
    return await this.sendCommand<ScreenResolution>('getScreenResolution', {});
  }

  /**
   * Wait for a specified duration
   * 
   * @param ms - Milliseconds to wait
   */
  async wait(ms: number): Promise<void> {
    await new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * Scroll the mouse wheel
   * 
   * @param deltaX - Horizontal scroll amount
   * @param deltaY - Vertical scroll amount
   */
  async scroll(deltaX = 0, deltaY = 0): Promise<void> {
    await this.sendCommand('scroll', { deltaX, deltaY });
  }

  /**
   * Drag the mouse from one position to another
   * 
   * @param fromX - Starting X coordinate
   * @param fromY - Starting Y coordinate
   * @param toX - Ending X coordinate
   * @param toY - Ending Y coordinate
   * @param options - Movement options
   */
  async drag(fromX: number, fromY: number, toX: number, toY: number, options: MoveOptions = {}): Promise<void> {
    this.log('Dragging from', fromX, fromY, 'to', toX, toY);
    
    await this.move(fromX, fromY);
    await this.mouseDown();
    await this.move(toX, toY, options);
    await this.mouseUp();
  }

  /**
   * Press and hold the left mouse button
   */
  async mouseDown(): Promise<void> {
    await this.sendCommand('mouseDown', {});
  }

  /**
   * Release the left mouse button
   */
  async mouseUp(): Promise<void> {
    await this.sendCommand('mouseUp', {});
  }

  /**
   * Check if connected to a VM
   * 
   * @returns True if connected
   */
  isConnected(): boolean {
    return this.connected;
  }

  /**
   * Get the current VM ID
   * 
   * @returns VM ID or null if not connected
   */
  getCurrentVMId(): string | null {
    return this.vmId;
  }

  /**
   * Close the connection to the VM
   */
  async close(): Promise<void> {
    this.log('Closing connection');
    
    if (this.ws) {
      // Clear any pending messages
      for (const [id, { reject }] of this.messageQueue) {
        reject(new Error('Connection closed'));
        this.messageQueue.delete(id);
      }
      
      this.ws.close();
      this.ws = null;
    }
    
    this.connected = false;
    this.vmId = null;
    this.emit('closed');
  }
}
