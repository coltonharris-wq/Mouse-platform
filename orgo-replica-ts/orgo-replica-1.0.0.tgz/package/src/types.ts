/**
 * Orgo Replica TypeScript SDK - Type Definitions
 * 
 * This file contains all TypeScript interfaces and types for the SDK.
 */

/**
 * VM (Virtual Machine) interface representing a cloud computer instance
 */
export interface VM {
  /** Unique identifier for the VM */
  id: string;
  
  /** Human-readable name for the VM */
  name: string;
  
  /** Current status of the VM */
  status: 'running' | 'stopped' | 'starting' | 'stopping' | 'error';
  
  /** VM specifications */
  specs: VMSpecs;
  
  /** Connection details */
  connection: VMConnection;
  
  /** Creation timestamp */
  createdAt: Date;
  
  /** Last activity timestamp */
  lastActivity: Date;
}

/**
 * VM Hardware Specifications
 */
export interface VMSpecs {
  /** Number of CPU cores */
  cpu: number;
  
  /** RAM in GB */
  memory: number;
  
  /** Storage in GB */
  storage: number;
  
  /** Operating system */
  os: string;
  
  /** Screen resolution */
  resolution?: ScreenResolution;
}

/**
 * Screen resolution
 */
export interface ScreenResolution {
  width: number;
  height: number;
}

/**
 * VM Connection details
 */
export interface VMConnection {
  /** WebSocket URL for real-time communication */
  wsUrl: string;
  
  /** HTTP API base URL */
  apiUrl: string;
  
  /** VNC connection URL (if available) */
  vncUrl?: string;
}

/**
 * Options for taking a screenshot
 */
export interface ScreenshotOptions {
  /** Image format (default: 'png') */
  format?: 'png' | 'jpeg' | 'webp';
  
  /** Image quality for lossy formats (1-100, default: 90) */
  quality?: number;
  
  /** Screen region to capture (captures full screen if not specified) */
  region?: CaptureRegion;
  
  /** Scale factor (default: 1) */
  scale?: number;
}

/**
 * Screen region for capture
 */
export interface CaptureRegion {
  x: number;
  y: number;
  width: number;
  height: number;
}

/**
 * Options for mouse click operations
 */
export interface ClickOptions {
  /** Mouse button to use (default: 'left') */
  button?: 'left' | 'right' | 'middle';
  
  /** Number of clicks (default: 1) */
  count?: number;
  
  /** Delay between clicks in ms (default: 50) */
  delay?: number;
}

/**
 * Options for typing text
 */
export interface TypeOptions {
  /** Delay between keystrokes in ms (default: 10) */
  delay?: number;
  
  /** Whether to press Enter after typing (default: false) */
  pressEnter?: boolean;
}

/**
 * Options for mouse movement
 */
export interface MoveOptions {
  /** Duration of movement in ms (default: 0 for instant) */
  duration?: number;
}

/**
 * Command execution result
 */
export interface CommandResult {
  /** Standard output */
  stdout: string;
  
  /** Standard error */
  stderr: string;
  
  /** Exit code */
  exitCode: number;
  
  /** Execution duration in ms */
  duration: number;
}

/**
 * File upload options
 */
export interface FileUploadOptions {
  /** Destination path on the VM */
  destination: string;
  
  /** File permissions (octal, e.g., '644') */
  permissions?: string;
}

/**
 * File download result
 */
export interface FileDownloadResult {
  /** File content as Buffer */
  data: Buffer;
  
  /** Original filename */
  filename: string;
  
  /** File size in bytes */
  size: number;
}

/**
 * Computer configuration options
 */
export interface ComputerConfig {
  /** API key for authentication */
  apiKey: string;
  
  /** API base URL (optional, uses default if not provided) */
  baseUrl?: string;
  
  /** Request timeout in ms (default: 30000) */
  timeout?: number;
  
  /** Enable debug logging */
  debug?: boolean;
}

/**
 * Mouse position
 */
export interface MousePosition {
  x: number;
  y: number;
}

/**
 * Keyboard key definitions
 */
export type Key = 
  | 'return' | 'enter' | 'tab' | 'space' | 'backspace' | 'delete'
  | 'escape' | 'up' | 'down' | 'left' | 'right'
  | 'home' | 'end' | 'pageup' | 'pagedown'
  | 'f1' | 'f2' | 'f3' | 'f4' | 'f5' | 'f6' | 'f7' | 'f8' 
  | 'f9' | 'f10' | 'f11' | 'f12'
  | 'shift' | 'control' | 'alt' | 'command' | 'win'
  | 'a' | 'b' | 'c' | 'd' | 'e' | 'f' | 'g' | 'h' | 'i' | 'j'
  | 'k' | 'l' | 'm' | 'n' | 'o' | 'p' | 'q' | 'r' | 's' | 't'
  | 'u' | 'v' | 'w' | 'x' | 'y' | 'z'
  | '0' | '1' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9';

/**
 * API Error response
 */
export interface APIError {
  code: string;
  message: string;
  details?: Record<string, unknown>;
}

/**
 * WebSocket message types
 */
export interface WSMessage {
  type: 'command' | 'response' | 'event' | 'error';
  id: string;
  payload: unknown;
}

/**
 * Browser automation options
 */
export interface BrowserOptions {
  /** Browser type */
  browser: 'chrome' | 'firefox' | 'safari';
  
  /** Headless mode */
  headless?: boolean;
  
  /** Window size */
  windowSize?: ScreenResolution;
  
  /** User agent */
  userAgent?: string;
}
