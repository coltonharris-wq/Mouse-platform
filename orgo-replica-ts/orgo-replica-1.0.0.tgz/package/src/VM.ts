/**
 * Orgo Replica TypeScript SDK - VM Class
 * 
 * VM management class for creating, listing, and managing virtual machines.
 */

import { EventEmitter } from 'events';
import {
  ComputerConfig,
  VM,
  VMSpecs,
  ScreenResolution,
  FileUploadOptions,
  FileDownloadResult,
} from './types.js';

/**
 * Create VM request body
 */
interface CreateVMRequest {
  name: string;
  specs: VMSpecs;
  image?: string;
}

/**
 * VM class for managing virtual machines
 * 
 * @example
 * ```typescript
 * import { VMManager } from 'orgo-replica';
 * 
 * const vms = new VMManager({ apiKey: 'your-api-key' });
 * 
 * // List all VMs
 * const vmList = await vms.list();
 * 
 * // Create a new VM
 * const newVM = await vms.create({
 *   name: 'my-vm',
 *   specs: { cpu: 2, memory: 4, storage: 50, os: 'ubuntu-22.04' }
 * });
 * 
 * // Start a VM
 * await vms.start(newVM.id);
 * 
 * // Stop a VM
 * await vms.stop(newVM.id);
 * 
 * // Delete a VM
 * await vms.delete(newVM.id);
 * ```
 */
export class VMManager extends EventEmitter {
  private apiKey: string;
  private baseUrl: string;
  private timeout: number;
  private debug: boolean;

  /**
   * Create a new VMManager instance
   * 
   * @param config - Configuration options
   */
  constructor(config: ComputerConfig) {
    super();
    
    if (!config.apiKey) {
      throw new Error('API key is required');
    }
    
    this.apiKey = config.apiKey;
    this.baseUrl = config.baseUrl || 'https://api.orgo-replica.com/v1';
    this.timeout = config.timeout || 30000;
    this.debug = config.debug || false;
  }

  /**
   * Log debug messages if debug mode is enabled
   */
  private log(...args: unknown[]): void {
    if (this.debug) {
      console.log('[OrgoReplica:VM]', ...args);
    }
  }

  /**
   * Make an HTTP request to the API
   */
  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const url = `${this.baseUrl}${endpoint}`;
    
    const headers: Record<string, string> = {
      'Authorization': `Bearer ${this.apiKey}`,
      'Content-Type': 'application/json',
      ...((options.headers as Record<string, string>) || {}),
    };

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.timeout);

    try {
      this.log('Request:', options.method || 'GET', url);
      
      const response = await fetch(url, {
        ...options,
        headers,
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: `HTTP ${response.status}` }));
        throw new Error(`API Error: ${(errorData as { message: string }).message} (${response.status})`);
      }

      return await response.json() as T;
    } catch (error: unknown) {
      clearTimeout(timeoutId);
      throw error;
    }
  }

  /**
   * List all VMs
   * 
   * @returns Array of VMs
   */
  async list(): Promise<VM[]> {
    this.log('Listing VMs');
    const response = await this.request<{ vms: VM[] }>('/vms');
    return response.vms;
  }

  /**
   * Get a specific VM by ID
   * 
   * @param vmId - VM identifier
   * @returns VM details
   */
  async get(vmId: string): Promise<VM> {
    this.log('Getting VM:', vmId);
    const response = await this.request<{ vm: VM }>(`/vms/${vmId}`);
    return response.vm;
  }

  /**
   * Create a new VM
   * 
   * @param name - VM name
   * @param specs - VM specifications
   * @param image - OS image (optional)
   * @returns Created VM
   */
  async create(name: string, specs: VMSpecs, image?: string): Promise<VM> {
    this.log('Creating VM:', name, specs);
    
    const body: CreateVMRequest = { name, specs };
    if (image) {
      body.image = image;
    }
    
    const response = await this.request<{ vm: VM }>('/vms', {
      method: 'POST',
      body: JSON.stringify(body),
    });
    
    this.emit('created', response.vm);
    return response.vm;
  }

  /**
   * Create a VM with common presets
   */
  
  /**
   * Create a basic VM with minimal specs
   */
  async createBasic(name: string, os = 'ubuntu-22.04'): Promise<VM> {
    return this.create(name, {
      cpu: 1,
      memory: 2,
      storage: 20,
      os,
    });
  }

  /**
   * Create a standard VM with moderate specs
   */
  async createStandard(name: string, os = 'ubuntu-22.04'): Promise<VM> {
    return this.create(name, {
      cpu: 2,
      memory: 4,
      storage: 50,
      os,
    });
  }

  /**
   * Create a performance VM with high specs
   */
  async createPerformance(name: string, os = 'ubuntu-22.04'): Promise<VM> {
    return this.create(name, {
      cpu: 4,
      memory: 16,
      storage: 100,
      os,
    });
  }

  /**
   * Start a VM
   * 
   * @param vmId - VM identifier
   */
  async start(vmId: string): Promise<void> {
    this.log('Starting VM:', vmId);
    await this.request(`/vms/${vmId}/start`, { method: 'POST' });
    this.emit('started', vmId);
  }

  /**
   * Stop a VM
   * 
   * @param vmId - VM identifier
   * @param force - Force stop (default: false)
   */
  async stop(vmId: string, force = false): Promise<void> {
    this.log('Stopping VM:', vmId);
    await this.request(`/vms/${vmId}/stop`, {
      method: 'POST',
      body: JSON.stringify({ force }),
    });
    this.emit('stopped', vmId);
  }

  /**
   * Restart a VM
   * 
   * @param vmId - VM identifier
   */
  async restart(vmId: string): Promise<void> {
    this.log('Restarting VM:', vmId);
    await this.request(`/vms/${vmId}/restart`, { method: 'POST' });
    this.emit('restarted', vmId);
  }

  /**
   * Delete a VM
   * 
   * @param vmId - VM identifier
   */
  async delete(vmId: string): Promise<void> {
    this.log('Deleting VM:', vmId);
    await this.request(`/vms/${vmId}`, { method: 'DELETE' });
    this.emit('deleted', vmId);
  }

  /**
   * Resize a VM
   * 
   * @param vmId - VM identifier
   * @param specs - New specifications
   */
  async resize(vmId: string, specs: Partial<VMSpecs>): Promise<VM> {
    this.log('Resizing VM:', vmId, specs);
    const response = await this.request<{ vm: VM }>(`/vms/${vmId}/resize`, {
      method: 'POST',
      body: JSON.stringify({ specs }),
    });
    this.emit('resized', response.vm);
    return response.vm;
  }

  /**
   * Set screen resolution for a VM
   * 
   * @param vmId - VM identifier
   * @param resolution - Screen resolution
   */
  async setResolution(vmId: string, resolution: ScreenResolution): Promise<void> {
    this.log('Setting resolution for VM:', vmId, resolution);
    await this.request(`/vms/${vmId}/resolution`, {
      method: 'POST',
      body: JSON.stringify(resolution),
    });
  }

  /**
   * Get available VM images/templates
   * 
   * @returns List of available images
   */
  async getAvailableImages(): Promise<string[]> {
    this.log('Getting available images');
    const response = await this.request<{ images: string[] }>('/images');
    return response.images;
  }

  /**
   * Wait for a VM to reach a specific status
   * 
   * @param vmId - VM identifier
   * @param status - Target status
   * @param timeout - Maximum wait time in ms (default: 60000)
   */
  async waitForStatus(
    vmId: string,
    status: VM['status'],
    timeout = 60000
  ): Promise<VM> {
    this.log('Waiting for VM', vmId, 'to reach status:', status);
    
    const startTime = Date.now();
    
    while (Date.now() - startTime < timeout) {
      const vm = await this.get(vmId);
      
      if (vm.status === status) {
        return vm;
      }
      
      if (vm.status === 'error') {
        throw new Error(`VM ${vmId} entered error state`);
      }
      
      // Wait 2 seconds before checking again
      await new Promise(resolve => setTimeout(resolve, 2000));
    }
    
    throw new Error(`Timeout waiting for VM ${vmId} to reach status ${status}`);
  }

  /**
   * Upload a file to a VM
   * 
   * @param vmId - VM identifier
   * @param localPath - Local file path
   * @param options - Upload options
   */
  async uploadFile(
    vmId: string,
    localPath: string,
    options: FileUploadOptions
  ): Promise<void> {
    this.log('Uploading file to VM:', vmId, localPath, '->', options.destination);
    
    const fs = await import('fs');
    const data = fs.readFileSync(localPath);
    
    await this.request(`/vms/${vmId}/files`, {
      method: 'POST',
      body: JSON.stringify({
        destination: options.destination,
        data: data.toString('base64'),
        permissions: options.permissions,
      }),
    });
  }

  /**
   * Download a file from a VM
   * 
   * @param vmId - VM identifier
   * @param remotePath - Remote file path
   * @returns File download result
   */
  async downloadFile(vmId: string, remotePath: string): Promise<FileDownloadResult> {
    this.log('Downloading file from VM:', vmId, remotePath);
    
    const response = await this.request<{ data: string; filename: string; size: number }>(
      `/vms/${vmId}/files?path=${encodeURIComponent(remotePath)}`
    );
    
    return {
      data: Buffer.from(response.data, 'base64'),
      filename: response.filename,
      size: response.size,
    };
  }
}

/**
 * VM presets for common use cases
 */
export const VMPresets = {
  /**
   * Minimal VM - Good for simple tasks
   */
  minimal: {
    cpu: 1,
    memory: 1,
    storage: 10,
    os: 'ubuntu-22.04',
  },
  
  /**
   * Basic VM - Good for development
   */
  basic: {
    cpu: 1,
    memory: 2,
    storage: 20,
    os: 'ubuntu-22.04',
  },
  
  /**
   * Standard VM - Good for most applications
   */
  standard: {
    cpu: 2,
    memory: 4,
    storage: 50,
    os: 'ubuntu-22.04',
  },
  
  /**
   * Performance VM - Good for intensive workloads
   */
  performance: {
    cpu: 4,
    memory: 16,
    storage: 100,
    os: 'ubuntu-22.04',
  },
  
  /**
   * High-performance VM - For demanding applications
   */
  highPerformance: {
    cpu: 8,
    memory: 32,
    storage: 200,
    os: 'ubuntu-22.04',
  },
} as const;

/**
 * Screen resolution presets
 */
export const ResolutionPresets = {
  /** 1366x768 - Laptop resolution */
  laptop: { width: 1366, height: 768 },
  
  /** 1920x1080 - Full HD */
  fullHD: { width: 1920, height: 1080 },
  
  /** 2560x1440 - 2K/QHD */
  qhd: { width: 2560, height: 1440 },
  
  /** 3840x2160 - 4K UHD */
  uhd: { width: 3840, height: 2160 },
  
  /** 1024x768 - XGA */
  xga: { width: 1024, height: 768 },
  
  /** 1280x720 - 720p HD */
  hd: { width: 1280, height: 720 },
} as const;
