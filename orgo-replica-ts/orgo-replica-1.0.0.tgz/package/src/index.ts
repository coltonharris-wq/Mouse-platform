/**
 * Orgo Replica TypeScript SDK
 * 
 * A TypeScript/JavaScript SDK for controlling cloud VMs via the Orgo Replica API.
 * 
 * @example
 * ```typescript
 * import { Computer, VMManager, VMPresets } from 'orgo-replica';
 * 
 * // Create a VM
 * const vms = new VMManager({ apiKey: 'your-api-key' });
 * const vm = await vms.create('my-vm', VMPresets.standard);
 * await vms.start(vm.id);
 * 
 * // Connect and control
 * const comp = new Computer({ apiKey: 'your-api-key' });
 * await comp.connect(vm.id);
 * 
 * const screenshot = await comp.screenshot();
 * await comp.click(100, 200);
 * await comp.type('Hello World');
 * 
 * await comp.close();
 * ```
 * 
 * @module orgo-replica
 */

// Main classes
export { Computer } from './Computer.js';
export { VMManager, VMPresets, ResolutionPresets } from './VM.js';

// Type definitions
export type {
  // Core types
  ComputerConfig,
  VM,
  VMSpecs,
  VMConnection,
  
  // Screen & Input types
  ScreenResolution,
  ScreenshotOptions,
  CaptureRegion,
  ClickOptions,
  TypeOptions,
  MoveOptions,
  MousePosition,
  
  // Command & File types
  CommandResult,
  FileUploadOptions,
  FileDownloadResult,
  
  // Keyboard
  Key,
  
  // Error & Message types
  APIError,
  WSMessage,
  
  // Browser automation
  BrowserOptions,
} from './types.js';

// Version
export const VERSION = '1.0.0';
